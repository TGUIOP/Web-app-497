package PartB;

public interface Card{
	
	public static final String [] card = {"two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "J", "Q", "K", "Ace"};
	public static final String [] suit = {"Dimond", "clubs", "spades" , "hearts"};
	
}