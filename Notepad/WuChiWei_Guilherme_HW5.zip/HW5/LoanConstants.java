package PartA;

public interface LoanConstants{
	
	public int ShortT = 1;
	public int MidT = 3;
	public int LongT = 5;
	public String CompName = "HW";
	public double MaxAmount = 100000;
	
}