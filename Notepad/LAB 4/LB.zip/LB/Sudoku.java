
class Sudoku {
	int game;
	int[]value;
	public Sudoku(int i, int j){
		this.game = i*j;
	}
	
	public boolean equal(int[]value, int[][]value2){
		boolean correct = false;
		boolean correct1 = false;
		
		for(int i=0; i < 9; i++){
			if(value[i] != value[i+1]){
				correct = true;
			}
		}
		for(int i=0; i < 9; i++){
			for(int j=0; j<9; j++){
				if(value2[i][j] != value2[i][j+1]){
				correct1 = true;
				}
			}
		}
		if((correct = true) && (correct1 = true)){
			return true;
		}
		else{
			return false;
		}
	}
}