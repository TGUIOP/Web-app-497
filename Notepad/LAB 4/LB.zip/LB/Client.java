
class Client{
	
	public static void main(String [] args){
		
		int range=(9-1)+1;
		int min=1;
		int rnd=(int)(Math.random()*(range)+min);
		
		Sudoku [][] myArray;
		myArray = new Sudoku [9][];
		for (int i=0; i<myArray.length; i++){
			int cols=(int) (Math.random()*(range)+min);
			myArray[i]=new Sudoku[cols];
		}
		for (int i=0; i<myArray.length; i++){
			for(int j=0; j<myArray[i].length;j++){
				myArray[i][j]=new Sudoku(i,j);
			}
		}
	}
}