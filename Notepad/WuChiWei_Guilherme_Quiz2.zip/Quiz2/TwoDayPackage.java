package A2;

public class TwoDayPackage extends Package implements ChargeConstants{
	
	public TwoDayPackage(String fromAddress, String toAddress, float weight){
		super(fromAddress, toAddress, weight);
	}
	
	public float calculateCharge(float weight){
		float charge;
		charge = weight*twoDayExtraCharge;
		charge = charge + super.calculateCharge(super.getWeight());
		return charge;
	}
	
	public String printReceipt(){
		String str = "Receipt for Package ID: " + super.getID() + "\n";
		str = str + "Type: Two Day" + "\n";
		str = str + "From Address: " + super.getFromAddress() + "\n";
		str = str + "To Address" + super.getToAddress() + "\n";
		str = str + "Weight: " + super.getWeight() + "oz." + "\n";
		str = str + "Charge: $" + calculateCharge(super.getWeight()) + "\n";
		return str;
	}
}