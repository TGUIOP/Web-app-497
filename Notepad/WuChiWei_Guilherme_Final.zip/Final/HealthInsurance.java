package PartA1;

public class HealthInsurance extends Insurance{
	
	public HealthInsurance(String name, int age, String type){
		super(name, age, type);
	}
	
	public void setCost(){
		int cost = 180;
	}
	
}