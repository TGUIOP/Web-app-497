package PartA1;

public class LifeInsurance extends Insurance{
	
	public LifeInsurance(String name, int age, String type){
		super(name, age, type);
	}
	
	public void setCost(){
		int cost = 40;
	}
}