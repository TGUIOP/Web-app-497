package PartB;

public interface SidedObject{
	
	public int displaySides();
	
}