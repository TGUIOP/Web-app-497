public interface letter{
	
	public final String [] letter = new String [] {" ", " ", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ"};
	
}