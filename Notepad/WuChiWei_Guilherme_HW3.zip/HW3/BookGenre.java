package library.services.classes;
public enum BookGenre {GENRE_HISTORY,GENRE_SCIENCE,GENRE_ENGINEERING,GENRE_LITERATURE}